import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-acceuill',
  templateUrl: './acceuill.component.html',
  styleUrls: ['./acceuill.component.scss']
})
export class AcceuillComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
