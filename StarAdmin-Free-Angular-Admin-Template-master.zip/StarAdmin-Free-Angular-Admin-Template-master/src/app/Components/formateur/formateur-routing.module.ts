import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AjoutformateurComponent } from './ajoutformateur/ajoutformateur.component';
import { SupprimeformateurComponent } from './supprimeformateur/supprimeformateur.component';
import { ModifierformateurComponent } from './modifierformateur/modifierformateur.component';
import { ListformateurComponent } from './listformateur/listformateur.component';
import { FormateurComponent } from './formateur/formateur.component';
import { DetatilsformateurComponent } from './detatilsformateur/detatilsformateur.component';
import { CalendrierformateurComponent } from './calendrierformateur/calendrierformateur.component';
import { AffecteformateurComponent } from './affecteformateur/affecteformateur.component';

const routes: Routes = [
    { path: 'formateur/lister', component: ListformateurComponent },
    { path: 'formateur/ajouter', component: AjoutformateurComponent },
         { path: 'formateur/modifier/:id', component: ModifierformateurComponent },
           { path: 'formateur/affecter', component:AffecteformateurComponent  },
           { path: 'formateur/calendrier', component:CalendrierformateurComponent  },

    { path: 'details/:id', component: DetatilsformateurComponent },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FormateurRoutingModule {
}
