import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AffectparticipntComponent } from './affectparticipnt.component';

describe('AffectparticipntComponent', () => {
  let component: AffectparticipntComponent;
  let fixture: ComponentFixture<AffectparticipntComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AffectparticipntComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AffectparticipntComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
