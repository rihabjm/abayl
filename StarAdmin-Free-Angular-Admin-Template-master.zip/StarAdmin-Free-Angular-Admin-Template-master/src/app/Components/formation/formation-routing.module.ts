import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListerformationComponent } from './listerformation/listerformation.component';
import { CalendrierformationComponent } from './calendrierformation/calendrierformation.component';
import { ChoisirpromotionComponent } from './choisirpromotion/choisirpromotion.component';

import { FormationComponent } from './formation/formation.component';
import { OuvrirsessionComponent } from './ouvrirsession/ouvrirsession.component';
import { AffichesessionComponent } from '../session/affichesession/affichesession.component';
import { ListformationmoduleComponent } from './listformationmodule/listformationmodule.component';
import { ListformationmetiersComponent } from './listformationmetiers/listformationmetiers.component';
import { PromotionComponent } from './promotion/promotion.component';
import { ListerprogrammekhdemniComponent } from './listerprogrammekhdemni/listerprogrammekhdemni.component';
const routes: Routes = [

     { path: 'formation/listerformationparmetiers', component: ListformationmetiersComponent },
      { path: 'formation/listerprogrammekhdemni', component: ListerprogrammekhdemniComponent },
     { path: 'formation/listerformationparmodule', component: ListformationmoduleComponent },
    { path: 'formation/listerformation', component: ListerformationComponent },
        { path: 'formation/calendrierformation/:id', component: CalendrierformationComponent },
     { path: 'formation/ouvrirsession', component:OuvrirsessionComponent  },
           { path: 'session/affichesession/:id', component:AffichesessionComponent  },
       { path: 'formation/promotion', component:PromotionComponent  },
     //    { path: ':id', component:ChoisirpromotionComponent  },
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FormationRoutingModule { }
