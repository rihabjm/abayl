import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Config} from '../Utils/Config';
import {Observable} from 'rxjs';
import {Formationmodule} from '../Model/formationmodule';
@Injectable({
  providedIn: 'root'
})
export class FormationmoduleService {
constructor(private httpClient: HttpClient) { }
private url = Config.BASE_URL + '/formationModule';
private urldetails = this.url + '/byid';
private urld = this.url + '/products';

  createProduct(product: object, idCategory: number): Observable<any> {
    return this.httpClient.post(`${this.urld}/${idCategory}`, product);
  }




 public save(formationmodule :Formationmodule): Observable<any> {

  return this.httpClient.post(this.url+'/add',formationmodule );
  }

  public  getAll(): Observable<Formationmodule[]> {
    return this.httpClient.get<Formationmodule[]>(this.url+'/get');
  }
 public update(formationmodule :Formationmodule): Observable<any> {

  return this.httpClient.put(this.url+'/update' ,formationmodule);
  }
 public delete(id): Observable<any> {
    return this.httpClient.delete(this.url + '/' + id);
  }
 public getformationBYintitule(intitule): Observable<Formationmodule[]> {
    return this.httpClient.get<Formationmodule[]>(this.url + '/byintitule/' + intitule);
  }
 public getformationBycategorie(categorie): Observable<Formationmodule[]> {
    return this.httpClient.get<Formationmodule[]>(this.url + '/bycategorie/' + categorie);
  }
public getformationBytype(type): Observable<Formationmodule[]> {
    return this.httpClient.get<Formationmodule[]>(this.url + '/bytype/' + type);
  }
public getformationByprix(prix): Observable<Formationmodule[]> {
    return this.httpClient.get<Formationmodule[]>(this.url + '/byprix/' + prix);
  }


    public get(id: number): Observable<any> {
    return this.httpClient.get(`${this.urldetails }/${id}`);
  }

}
