import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Config} from '../Utils/Config';
import {Observable} from 'rxjs';
import {Promotion} from '../Model/promotion';
@Injectable({
  providedIn: 'root'
})
export class PromotionService {

 constructor(private httpClient: HttpClient) { }
private url = Config.BASE_URL + '/promotion';
private urldetails = this.url + '/byid';

 public save(promotion:Promotion): Observable<any> {

  return this.httpClient.post(this.url+'/add',promotion );
  }

  public  getAll(): Observable<Promotion[]> {
    return this.httpClient.get<Promotion[]>(this.url+'/get');
  }
 public update(promotion:Promotion): Observable<any> {

  return this.httpClient.put(this.url+'/update' ,promotion);
  }

   public getpromotion(id: number): Observable<any> {
    return this.httpClient.get(`${this.urldetails }/${id}`);
  }

   public delete(id): Observable<any> {
    return this.httpClient.delete(this.url + '/' + id);
  }



}
