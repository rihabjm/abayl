export class Specilaite {
idspecialite :number ;
nomspecialite :String ;


}
