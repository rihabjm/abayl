export class Files {
  id :number ;

file_name: String ;
file_type:String ;
}
