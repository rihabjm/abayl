import { Seance } from './seance';

describe('Seance', () => {
  it('should create an instance', () => {
    expect(new Seance()).toBeTruthy();
  });
});
