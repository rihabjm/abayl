import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccplateformeComponent } from './accplateforme.component';

describe('AccplateformeComponent', () => {
  let component: AccplateformeComponent;
  let fixture: ComponentFixture<AccplateformeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccplateformeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccplateformeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
